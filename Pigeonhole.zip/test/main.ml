open OUnit2
let tests = "pigeonhole test suite" >::: [ ]
let _ = run_test_tt_main tests